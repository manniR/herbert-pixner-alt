<div class="container">
<div class="row">
	<h4>Used Images &copy; Creative Commons-licensed content </h4>
  <div class="col-sm-6 col-md-3">
    <div class="thumbnail">
<div about='http://farm6.static.flickr.com/5125/5268714893_68e885e229_m.jpg'><a href='http://www.flickr.com/photos/loop_oh/5268714893/' target='_blank'><img xmlns:dct='http://purl.org/dc/terms/' href='http://purl.org/dc/dcmitype/StillImage' rel='dct:type' src='http://farm6.static.flickr.com/5125/5268714893_68e885e229_m.jpg' alt='red sky by loop_oh, on Flickr' title='red sky by loop_oh, on Flickr' border='0'/></a><br/><a rel='license' href='http://creativecommons.org/licenses/by-nd/2.0/' target='_blank'><img src='http://i.creativecommons.org/l/by-nd/2.0/80x15.png' alt='Creative Commons Attribution-No Derivative Works 2.0 Generic License' title='Creative Commons Attribution-No Derivative Works 2.0 Generic License' border='0' align='left'></a>&nbsp;&nbsp;by&nbsp;<a href='http://www.flickr.com/people/loop_oh/' target='_blank'>&nbsp;</a><a xmlns:cc='http://creativecommons.org/ns#' rel='cc:attributionURL' property='cc:attributionName' href='http://www.flickr.com/people/loop_oh/' target='_blank'>loop_oh</a><a href='http://www.imagecodr.org/' target='_blank'>&nbsp;</a></div>      <div class="caption">
        <h3> <strong><a href="http://www.flickr.com/photos/loop_oh/5268714893/" target="_blank">red sky</a></strong> from <strong><a href="http://www.flickr.com/people/loop_oh/" target="_blank">loop_oh</a></strong>. </h3>
      </div>
    </div>
  </div>
</div>

<div class="panel panel-info">
    <div class="panel-heading">
            <h4><span class="glyphicon glyphicon-thumbs-up"></span> Thanks to:</h4>
    </div>
	<div class="panel-body">
    	<div class="media-item col-md-6 col-lg-3">
         <ul class="media-list">
          <li class="media">
            <a class="pull-left" href="#">
              <img class="media-object" width="64" src="<?php echo get_template_directory_uri().'/rsc/img/ph.jpg' ?>" alt="ph">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Bootstrap </h4>
              The bootstrap team, for making it too easy for all of us.
            </div>
          </li>
        </ul>
       </div>
           	<div class="media-item col-md-6 col-lg-3">
         <ul class="media-list">
          <li class="media">
            <a class="pull-left" href="#">
              <img class="media-object" width="64" src="<?php echo get_template_directory_uri().'/rsc/img/ph.jpg' ?>" alt="ph">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Option Framework </h4>
              For the theme options framework
            </div>
          </li>
        </ul>
       </div>
           	<div class="media-item col-md-6 col-lg-3">
         <ul class="media-list">
          <li class="media">
            <a class="pull-left" href="#">
              <img class="media-object" width="64" src="<?php echo get_template_directory_uri().'/rsc/img/ph.jpg' ?>" alt="ph">
            </a>
            <div class="media-body">
              <h4 class="media-heading">320 Themes </h4>
              For the basic bootstrap theme & the idea.
            </div>
          </li>
        </ul>
       </div>
           	<div class="media-item col-md-6 col-lg-3">
         <ul class="media-list">
          <li class="media">
            <a class="pull-left" href="#">
              <img class="media-object" width="64" src="<?php echo get_template_directory_uri().'/rsc/img/ph.jpg' ?>" alt="ph">
            </a>
            <div class="media-body">
              <h4 class="media-heading">Of course, WP </h4>
              Last but not the least..
            </div>
          </li>
        </ul>
       </div>
   </div>
</div>
 
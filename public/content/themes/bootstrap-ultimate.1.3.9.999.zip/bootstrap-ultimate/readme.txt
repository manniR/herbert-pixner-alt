BOOTSTRAP ULTIMATE - Bootstrap UL
===================

Bootstrap (http://getbootstrap.com/ in WP at its finest. 

FEATURES
________

I've started this template just because i couldnt find a template for bootstrap 3. My primary goal was only to update the markup for v3, but thing got out of hand and it has grown into something on its own.
The theme features all bootstrap components in frontend & in addition a full-fledged options panel in backend. Comes with many distinctive features as auto Google Fonts & Bootswatch updates.
Also there can be other "features" yet to be explored, or like some of you call them as "bugs", if you find one please report (:
Star this project on Github to keep up with its progress.

Fast & Responsive
__________

The theme is essentially built for speed; i.e. you get load times under 1 second with default settings. It's also meant to act mainly like a base theme to build on top of for your projects.

Page Templates
______________

The template incorporates a "layout option" in post / page writing panel instead of custom layout page templates. I might add actually useful page templates later on, like a gallery or portfolio template.

Theme Options Panel
___________________

Option panel took most of the time really, debugging, extending it. It's built on top of great OptionsFramework.

Shortcodes
__________

I'd like to add bootstrap [shortcodes] for quickly adding bootstrap compoenents in your posts but unfortunately not allwed in themes due to "plugin territory".

Sidebars
________

Currently you only have the option to change the place of the sidebar. Sidebar & widget improvements are for later.

CREDIT
________

Used bootstrap theme by 320themes &  Eddie Machado's Bones as a starting point.

Emin Özlem - info@eodepo.com